void	my_aff(int);




void return1(int sig)
{
  my_aff(0);
}

void return2(int sig)
{
  my_aff(1);
}
