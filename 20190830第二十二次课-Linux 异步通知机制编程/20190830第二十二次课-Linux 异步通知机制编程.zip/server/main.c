

int	my_server(void);

int	main()
{
  if (my_server() == -1)
    return (-1);
  return (0);
}
