/*********************************************************************
* 版权所有 (C)2016
*
* 文件名称： // 链表实现
* 文件标识： //
* 内容摘要： // 链表实现
* 其它说明： // 
* 当前版本： // v1
* 作    者： // Chandler
* 完成日期： // 2016/04/09
*
* 修改日期        版本号     修改人	      修改内容
* ---------------------------------------------------------------
* 2016/04/09	      V1.0 链表实现  *********************/
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include "List.h"



/**********************************************************************
 * 函数名称： ListLinkInit
 * 功能描述： 构建一个空的链表
 * 输入参数：
 * 输出参数： T_list结构体指针（链表结构体指针）
 * 返 回 值： T_list结构体指针（链表结构体指针）
 * 修改日期        版本号     修改人	      修改内容
 * -----------------------------------------------
 * 2016/04/09	     V1.0	  Chandler	      修改
 ***********************************************************************/
Pt_list ListLinkInit(void)
{
	//构建一个链表结构体
	Pt_list plistlink=(Pt_list)malloc(sizeof(T_list));
	//让结构体成员 prear pfront为NULL length=0
	if(plistlink !=NULL)
	{
		plistlink->pfront=NULL;
		plistlink->prear=NULL;
		plistlink->length=0;		
	}
	//返回这个结构体的指针
	return plistlink;
}

/**********************************************************************
 * 函数名称： IsEmpty
 * 功能描述： 判断链表是否为空
 * 输入参数： 
 *			  Pt_list		需要判断的链表
 * 输出参数： 结果
 * 返 回 值： 1：空
 *			  0：不为空
 * 修改日期        版本号     修改人	      修改内容
 * -----------------------------------------------
 * 2016/04/09	     V1.0	  Chandler	      修改
 ***********************************************************************/
 u8 IsEmpty(Pt_list ptlist)
 {
	//如果一个链表 头指针为空 尾指针为空 长度为0 就是空链表
	 if((ptlist->prear==NULL)&&(ptlist->pfront==NULL)&&(0==ptlist->length))
	 {
		 return 1;
	 }
	 else
	 {
		 return 0;
	 }
 }
 
/**********************************************************************
 * 函数名称： RegisterList
 * 功能描述： 把结点放入链表
 * 输入参数： 
 *			  T_ListLinkNode   需要添加的结点指针
 *			  Pt_list		添加入链表的指针
 * 输出参数： 空
 * 返 回 值： void
 * 修改日期        版本号     修改人	      修改内容
 * -----------------------------------------------
 * 2016/04/09	     V1.0	  Chandler	      修改
 ***********************************************************************/
void RegisterList(Pt_list ptlist,Pt_ListLinkNode ptlistnode)
{
	//判断链表是否为空
	if(IsEmpty(ptlist)!=1)
	{
		//链表不为空 找到链表的尾节点 把当前的节点加入尾节点的下一个
		ptlist->prear->pt_next=ptlistnode;
	}
	else
	{
		//链表为空，把当前结点地址赋值给首指针
		ptlist->pfront=ptlistnode;
	}
		ptlist->prear=ptlistnode;
		ptlist->length++;
}


/**********************************************************************
 * 函数名称： DeleteList
 * 功能描述： 删除头节点或某个节点
 * 输入参数： 
 *			  Pt_ListLinkNode   存放删除了的节点数据的节点指针
 *			  Pt_list		添加入链表的指针
 * 输出参数： Pt_ListLinkNode
 * 返 回 值： Pt_ListLinkNode
 * 修改日期        版本号     修改人	      修改内容
 * -----------------------------------------------
 * 2016/04/09	     V1.0	  Chandler	      修改
 ***********************************************************************/
Pt_ListLinkNode DeleteList(Pt_list ptlist,Pt_ListLinkNode ptlistnode)
{
	Pt_ListLinkNode ptnode=ptlist->pfront;
	//判断链表是否为空
	if(IsEmpty(ptlist)!=1)
	{
		//从ptnode（待删除的节点）拷贝sizeof（）的大小到传入的备份节点
		memcpy(ptlistnode,ptnode,sizeof(T_ListLinkNode));
		//链表长度自减
		ptlist->length--;
		//更新链表的首地址
		ptlist->pfront=ptlist->pfront->pt_next;
		//释放被删除节点的内存（堆）
		free(ptnode);
		//如果当前链表在删除之后没有结点 必须要把链表尾部置为NULL
		if(0==ptlist->length)
		{
			ptlist->prear=NULL;
		}
	}
	return ptlist->pfront;
}

/**********************************************************************
 * 函数名称： TraverseList
 * 功能描述： 查询链表 遍历链表
 * 输入参数： 
 *			  void(* Traverse)(Pt_NodeStruct ptnodestruct)查询函数指针
 *			  Pt_list		添加入链表的指针
 * 输出参数： void
 * 返 回 值： void
 * 修改日期        版本号     修改人	      修改内容
 * -----------------------------------------------
 * 2016/04/09	     V1.0	  Chandler	      修改
 ***********************************************************************/
void TraverseList(Pt_list ptlist,void(* Traverse)(Pt_NodeStruct ptnodestruct))
{
	//建立两个临时的变量，存储链表的length和首地址，不要直接对链表结构体做操作
	Pt_ListLinkNode pnode=ptlist->pfront;
	u32 listsize=ptlist->length;
	//对链表中的每一个结点调用Traverse查询函数
	while(listsize)
	{
		Traverse(&pnode->t_data);
		pnode=pnode->pt_next;
	}
}

/**********************************************************************
 * 函数名称： ClearList
 * 功能描述：  清空一个链表
 * 输入参数： 
 *			  Pt_list		需要销毁链表的指针
 * 输出参数： void
 * 返 回 值： void
 * 修改日期        版本号     修改人	      修改内容
 * -----------------------------------------------
 * 2016/04/09	     V1.0	  Chandler	      修改
 ***********************************************************************/
 void ClearList(Pt_list ptlist)
 {
	 while(IsEmpty(ptlist)!=1)
	 {
		 DeleteList(ptlist,NULL);
	 }
 }
 
 
/**********************************************************************
 * 函数名称： DestroyList
 * 功能描述： 销毁一个链表
 * 输入参数： 
 *			  Pt_list		需要销毁链表的指针
 * 输出参数： void
 * 返 回 值： void
 * 修改日期        版本号     修改人	      修改内容
 * -----------------------------------------------
 * 2016/04/09	     V1.0	  Chandler	      修改
 ***********************************************************************/
 void DestroyList(Pt_list ptlist)
 {
	if(IsEmpty(ptlist)!=1)
	{
		ClearList(ptlist);		
	}
	else
	{
		ptlist->pfront=NULL;
		ptlist->prear=NULL;
		ptlist->length=0;
	}
 }
 
 
 /**********************************************************************
 * 函数名称： GetListSize
 * 功能描述： 获取链表的长度
 * 输入参数： 
 *			  Pt_list		需要获取链表的长度
 * 输出参数： u32	size	当前链表长度
 * 返 回 值： u32	size
 * 修改日期        版本号     修改人	      修改内容
 * -----------------------------------------------
 * 2016/04/09	     V1.0	  Chandler	      修改
 ***********************************************************************/
 u32 GetListSize(Pt_list ptlist)
 {
	return ptlist->length;
 }
 
 
 





